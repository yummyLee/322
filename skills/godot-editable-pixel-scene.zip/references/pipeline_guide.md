# 3渲2 像素渲染管线深度技术指南

本参考文档深入解析 Godot 4 中实现高质量 3渲2（3D-to-2D Pixel Art）的核心渲染原理、数学公式与常见陷阱避坑。

---

## 1. 正交相机（Orthographic Camera）与像素吸附

在 3渲2 场景中，必须使用正交投影（`PROJECTION_ORTHOGONAL`），以消除透视形变，保持 2D 插画特有的轴测/平行透视美感。

### 像素大小与视口换算
当使用低分辨率渲染或者整数倍放大像素时，相机在世界空间中的一个像素跨度为：

$$\text{Pixel World Unit} = \frac{\text{Camera.size}}{\text{Viewport.size.y}}$$

例如：
- 相机 `size = 36.0`（垂直覆盖 36 米）。
- 低分辨率 `SubViewport.size.y = 360`（1080p 配合 3×3 像素块）。
- 则屏幕上每一个像素格对应世界坐标系中恰好：
  $$\frac{36.0}{360} = 0.10 \text{ 米}$$

### 亚像素平移抖动与吸附（Pixel Snapping）
当玩家控制角色移动或相机跟随平移时，若相机位置在两格像素之间连续浮点变化，会导致画面中所有几何体边缘在两个屏幕像素间反复跳变（Pixel Swimming / Jittering）。
解决办法是在相机跟随逻辑中将目标位置沿相机自身正交基对齐到像素网格步长：

```gdscript
var step: float = camera.size / float(viewport.size.y)
var local_x: float = floor(target_cam_pos.dot(camera.basis.x) / step) * step
var local_y: float = floor(target_cam_pos.dot(camera.basis.y) / step) * step
# 沿正交基重构对齐后的世界坐标
```
> [!NOTE]
> 像素吸附主要针对相机平移（Translation）。正交相机的旋转仍会引发像素重构，因此在游玩状态下通常锁定角度，仅在观察模式下旋转。

---

## 2. Godot 4.3+ Reverse-Z 与全屏后处理 Quad

### 什么是 Reverse-Z？
从 Godot 4.3 开始，Forward+ 和移动端 Vulkan/D3D12 渲染器采用了 Reverse-Z 逆向深度缓冲体系：
- 近平面（Near Plane）映射为深度值 $1.0$。
- 远平面（Far Plane）映射为深度值 $0.0$。
这样可以在广阔的远景中提供极高浮点精度，大幅减少 Z-fighting。

### 全屏 Quad 的正确写法
在传统 OpenGL 中，覆盖全屏的 Quad 顶点坐标常设为 `POSITION = vec4(VERTEX.xy, -1.0, 1.0);`。但在 Reverse-Z 环境下，必须写为：
```glsl
void vertex() {
    POSITION = vec4(VERTEX.xy, 1.0, 1.0);
}
```
此时后处理面片会被精准推到近平面上，完美遮盖整个视口，且不会被普通 3D 物体裁剪。

### 编辑器隐藏原则
全屏 Quad 必须在场景中设置 `visible = false`，仅在运行时脚本 `_ready()` 中开启：
```gdscript
outline.visible = true
```
**原因**：如果在编辑器中 `visible = true`，当开发者在 Godot 编辑器中旋转 3D 视图时，由于全屏 Quad 材质使用了屏幕纹理采样和不可见深度写入，会遮挡整个编辑器 3D 操作视口，导致无法编辑场景。

---

## 3. 边缘检测算法：深度差 vs 法线差

`outline.gdshader` 采用 4-tap（上下左右各偏移 1 像素）采样策略：

### 1. 外轮廓线（Silhouette / Depth Step）
当中心像素与邻近像素的深度差超过阈值时：
```glsl
edge = max(edge, step(0.22, nd - d));
```
由于背景像素深度远大于前景像素，`nd - d` 突变为正值，形成轮廓黑边（颜色乘以深青灰调 `col * vec3(0.42, 0.46, 0.57)`，而不是生硬的死黑）。

### 2. 内部结构线与高亮（Inner Creases & Upward Highlights）
通过法线点积检测夹角：
```glsl
detail = max(detail, step(0.22, 1.0 - dot(n, nn)) * (1.0 - step(0.2, abs(nd - d))) * step(0.05, n.y - nn.y));
```
- `1.0 - dot(n, nn)`：检测两面折角（如屋檐立面与屋面、墙角转折）。
- `(1.0 - step(0.2, abs(nd - d)))`：排除深度大断层，防止与外轮廓线重叠。
- `step(0.05, n.y - nn.y)`：当上方表面的 Y 法线大于侧面时，说明是受天光照射的朝天棱边，混合边缘提亮（`col * 1.3 + 0.04`）。

---

## 4. 材质层：分阶光照与空间散斑（style.gdshader）

### 分阶光照（Toon Ramp）
在 `light()` 函数中将漫反射光强度量化为 3 级：
```glsl
float n = max(dot(NORMAL, LIGHT), 0.0);
float shade = toon_enabled ? floor(n * 3.0 + 0.001) / 3.0 : n;
DIFFUSE_LIGHT += ALBEDO * LIGHT_COLOR * shade * ATTENUATION / PI;
```
这样使得建筑平整墙体和山石呈现手绘原画中的明暗受光面切分。

### 空间散斑（World-space Grain）
低模纯色材质容易出现数字 CG 的“塑料平整感”。通过 3D 世界坐标的 Hash 扰动：
```glsl
float fine = hash3(floor(world_position * 13.0));
float patches = hash3(floor(world_position * 3.0));
ALBEDO = base_color.rgb * (1.0 + (fine - 0.5) * grain + (patches - 0.5) * grain * 0.55);
```
将网格表面打散为微小的颗粒网纹，类似手绘水粉纸或印刷网点，与像素描边完美融合。
