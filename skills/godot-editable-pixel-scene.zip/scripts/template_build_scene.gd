extends "village_parts.gd"
# ==============================================================================
# template_build_scene.gd
# 场景自动建模与烘焙脚本模板。
# Run: godot --headless --path PROJECT --script res://scene_kit/tools/build_scene.gd -- --bake
# ==============================================================================

const OUTPUT := "res://scene_kit/world.tscn"

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if not "--bake" in args or (FileAccess.file_exists(OUTPUT) and not "--overwrite" in args):
		push_error("Authoring requires -- --bake; replacing the saved scene additionally requires --overwrite.")
		quit(1)
		return
	
	# 载入 3渲2 材质 Shader
	shader = load("res://scene_kit/style.gdshader")
	rng.seed = 123456
	
	# 根节点命名并开始组装
	scene_root = Node3D.new()
	scene_root.name = "World"
	
	build_terrain()
	build_architecture()
	build_landmarks()
	build_nature()
	build_render_rig()
	
	var err := save_scene(OUTPUT)
	scene_root.free()
	quit(err)

func build_terrain() -> void:
	var ground := group(scene_root, "Terrain")
	# 基底土壤与草地
	box(ground, "Earth", Vector3(0, -0.4, 0), Vector3(80, 0.8, 64), "7d7955")
	box(ground, "GrassBase", Vector3(0, 0.015, 0), Vector3(80, 0.08, 64), "8f9c72")
	box(ground,"Courtyard",Vector3(0,0.08,0),Vector3(13,0.08,10),"d5c69b")

func build_architecture() -> void:
	var buildings := group(scene_root, "Buildings")
	house(buildings,"MainHouse",Vector3(0,0,-2),6.0,3.5,2.8,false,"c6bfa0")
	stone_wall(buildings,"YardWall",Vector3(-5,0,2),Vector3(-2,0,2))

func build_landmarks() -> void:
	var props := group(scene_root, "VillageLife")
	pot(props,Vector3(2,0,1),0.35)

func build_nature() -> void:
	var forest := group(scene_root, "ForestBoundary")
	tree(forest,Vector3(-5,0,-2),1.0)
	tree(forest,Vector3(5,0,2),0.9)

func build_render_rig() -> void:
	var rig := group(scene_root, "RenderRig")
	
	# 环境背景与环境光
	var env_node := WorldEnvironment.new()
	env_node.name = "VillageEnvironment"
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("6b775b")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("d6dfe5")
	env.ambient_light_energy = 0.8
	env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	env_node.environment = env
	rig.add_child(env_node)
	env_node.owner = scene_root
	
	# 阳光方向光
	var sun := DirectionalLight3D.new()
	sun.name = "SunLight"
	sun.rotation_degrees = Vector3(-58, -28, 0)
	sun.light_color = Color("fff4df")
	sun.light_energy = 1.6
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 110
	rig.add_child(sun)
	sun.owner = scene_root
	
	# 正交像素相机
	var camera := Camera3D.new()
	camera.name = "VillageCamera"
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 16.0
	camera.far = 160.0
	camera.position = Vector3(0, 46, 43)
	camera.rotation_degrees = Vector3(-47, 0, 0)
	camera.current = true
	rig.add_child(camera)
	camera.owner = scene_root
	
	# 3渲2 逆Z深度与法线描边后处理 Quad（编辑器中隐藏，运行时激活）
	var quad := MeshInstance3D.new()
	quad.name = "PixelOutline"
	var mesh := QuadMesh.new()
	mesh.size = Vector2(2, 2)
	quad.mesh = mesh
	quad.extra_cull_margin = 16384
	quad.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var post := ShaderMaterial.new()
	post.shader = load("res://scene_kit/outline.gdshader")
	quad.material_override = post
	quad.visible = false
	camera.add_child(quad)
	quad.owner = scene_root
	quad.position.z = -1.0
