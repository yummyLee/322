---
name: godot-editable-pixel-scene
description: Build editable Godot 4 3D pixel-art scenes from environment reference images, baking geometry into tscn and using an orthographic low-resolution render pipeline. Use for 3渲2 scene construction and modular scene expansions.
---

# Editable 3D Pixel Scenes (3渲2 场景制作与扩展)

- **参考图解构**：从 2D 环境原画或概念图中提取空间布局、地标轮廓、屋顶制式（茅草/青瓦/飞檐）、色彩 Hex 调色板与植被层次。以真实 3D 块体和网格重构几何空间，严禁使用参考图作为扁平背景。
- **纯原生可编辑 `.tscn`**：所有建筑模型、语义分组、物理碰撞、相机、光照与后处理节点必须保存为 `.tscn` 中的实际节点。打开场景即可在 Godot 编辑器中查看、框选和编辑。代码仅用于一次性生成/烘焙，运行时直接加载已保存场景，绝不动态重建覆盖用户的修改。
- **制作工具链与构件库**：
  - [scripts/bake_helpers.gd](./scripts/bake_helpers.gd)：基础节点层级、所有权管理 (`node.owner = scene_root`)、基础几何图元缓存与场景保存。
  - [scripts/village_parts.gd](./scripts/village_parts.gd)：东亚/古风乡村模块化构件（`house()`、`roof()`、`stone_wall()`、`fence()`、`pot()`、`tree()` 等）。
  - [scripts/template_build_scene.gd](./scripts/template_build_scene.gd)：新场景或扩展地块生成脚本模板。
  - 命令行生成执行：`godot --headless --path PROJECT --script res://... -- --bake`，覆盖已存文件必须附加 `--overwrite`。
- **3渲2 渲染管线**：
  - 正交相机（`PROJECTION_ORTHOGONAL`），低分辨率 SubViewport 配合整数倍最近邻缩放（`filter_nearest`）。
  - 材质着色器：[resources/style.gdshader](./resources/style.gdshader) 提供 3-Tone 分阶光照与 3D 空间坐标散斑微质感。
  - 全屏后处理：[resources/outline.gdshader](./resources/outline.gdshader) 挂载在相机前 Quad（`visible = false` 避免阻挡编辑器视口，运行时开启）。**必须适配 Godot 4.3+ Reverse-Z**：`POSITION = vec4(VERTEX.xy, 1.0, 1.0);`，结合 4 邻域深度跳跃外轮廓与法线折角提亮。
  - 相机平移吸附：位移量按 `camera.size / viewport.size.y` 步长取整，消除亚像素移动抖动。
- **场景扩展与拼接流程**：
  - 详细技术细节与接缝平滑请参阅 [references/scene_expansion_guide.md](./references/scene_expansion_guide.md)。
  - 管线数学原理与逆 Z 剖析参阅 [references/pipeline_guide.md](./references/pipeline_guide.md)。
- **验证准则**：Godot 无报错导入，检查节点层级与所有权，真机 GPU 验证普通 3D 与像素 3渲2 渲染表现，验证角色移动与碰撞。
